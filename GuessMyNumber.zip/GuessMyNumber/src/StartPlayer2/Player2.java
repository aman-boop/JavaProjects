package StartPlayer2;
import StartMain.*;
import java.util.*;
import java.io.*;

public class Player2
{
	public void startP2(String Player1Name, String Player2Name,int P1Point,int P2Point) throws FileNotFoundException
	{
	    Scanner input = new Scanner(System.in);
		System.out.println("_______________________");
		System.out.println(Player2Name + ":Guess Number");
		System.out.println("_______________________");
		
		String Address = "/storage/emulated/0/MainProjects/GuessMyNumber/src/Points/P2Points.txt";
		String Address2 = "/storage/emulated/0/MainProjects/GuessMuNumber/src/Points/P1Points.txt";
		int Points=P2Point;
		do{
			int RandomNumber = (int)(Math.random() * 10);
			System.out.println(RandomNumber);
			int InputNum = input.nextInt();
			
			if (Points == 10)
			{
				Points=0;
				String P1Name,P2Name;
				Scanner InNames = new Scanner(System.in),Inchar = new Scanner(System.in);
				
				System.out.println("***********************");
				System.out.println(Player2Name + " " + "is Wins"+" & "+Player2Name+" "+"points is"+" "+"("+Points+")"+" & "+Player1Name+" "+"points is"+" "+"("+P1Point+")");
				System.out.println("***********************");
				System.out.println();
				System.out.println("Do want to play again y/n");
			//Delete points txt files
				File D = new File(Address);
				D.delete();
				File D2 = new File(Address2);
				D2.delete();
				
				char yes = Inchar.next().charAt(0);
				if(yes=='y' || yes=='Y'){
			//Inputing names from users (Starting)
					System.out.println("P1 enter your name");
					P1Name = InNames.nextLine();
					
					System.out.println("P2 enter your name");
					P2Name = InNames.nextLine();
			//Inputing names from users (Ended)
			     
			    Player1 R = new Player1();
				R.startP1(P1Name,P2Name,Points,P1Point);
				}
		    }

			if (InputNum == RandomNumber)
			{
				System.out.println("========================================");
				System.out.println("Yout Enter Right Numbers");
				System.out.println(Player2Name + ":Got 1 Point or One More Try");
				System.out.println("========================================");
				Points++;
				File AddPoints = new File(Address);
				try
				{
					AddPoints.createNewFile();
				}
				catch (IOException e)
				{
					System.out.println("Error!" + e);
				}
				try
				{
					FileWriter PointFile = new FileWriter("/storage/emulated/0/MainProjects/GuessMyNumber/src/Points/P2Points.txt");
					PointFile.write(Player2Name + "=" + "Points " + "(" + P2Point + ")");
					PointFile.close();
				}
				catch (IOException e)
				{
					System.out.println("Error!"+e);
				}
			}
			else if (InputNum == 3485)
			{
				File Delete = new File(Address);
				Delete.deleteOnExit();
				File Delete2 = new File(Address2);
				Delete2.deleteOnExit();
				System.exit(1);
			}
			else if (InputNum == 209885)
			{            File file = new File(Address);
				Scanner read = new Scanner(file);
				Points = P2Point;
				System.out.println("***************");
				read.useDelimiter("\\z");
				System.out.println(read.next());
				System.out.println("***************");
		    }
			else
			{
				Player1 P1 = new Player1();
				P1.startP1(Player1Name, Player2Name,P1Point,Points);
			}
			
		}while(Points != 11);
	}
}
