import java.util.*;
import StartMain.*;
import java.io.*;

public class Main
{
	public static void main(String[] args) throws FileNotFoundException
	{
		int P1Point=0;
		int P2Point=0;
		String Address = "/storage/emulated/0/MainProjects/GuessMyNumber/src/Points/P1Points.txt";
		String Address2 = "/storage/emulated/0/MainProjects/GuessMyNumber/src/Points/P2Points.txt";
		File file = new File(Address);
		file.delete();
		File file2 = new File(Address2);
		file2.delete();
		//Enter  Playes Name
		Scanner input = new Scanner(System.in);
		System.out.println("Player 1: Enter your Name");
		String Player1 = input.nextLine();

		System.out.println("Player 2: Enter Your Name");
		String Player2 = input.nextLine();
		//Entering name is end
		System.out.println(Player1 + ":Points is(0)");
		System.out.println(Player2 + ":Points is(0)");
	    System.out.println("enter A number and\nhis match with my Number You got 1 point\nyour target get 10 points bye!");
		System.out.println("Enter y to Start");
		char Y = input.nextLine().charAt(0);

		if (Y == 'y' || Y=='Y')
		{
			Player1 P1 = new Player1();
			P1.startP1(Player1, Player2,P1Point,P2Point );
		}
	}
}
