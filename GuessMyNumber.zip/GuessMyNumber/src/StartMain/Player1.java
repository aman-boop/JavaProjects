package StartMain;
import java.util.*;
import java.math.*;
import StartPlayer2.*;
import java.io.*;

public class Player1
{

	public void startP1(String Player1Name, String Player2Name,int P1Point,int P2Point) throws FileNotFoundException
	{

		Scanner input = new Scanner(System.in);
		System.out.println("_________________________");
		System.out.println(Player1Name + ":Guess Number");
		System.out.println("_________________________");
		
		int Points=P1Point;
	
		String Address = "/storage/emulated/0/MainProjects/GuessMyNumber/src/Points/P1Points.txt";
		String Address2 = "/storage/emulated/0/MainProjects/GuessMyNumber/src/Points/P2Points.txt";
		do{
			System.out.println(Points);
			int RandomNumbers = (int)(Math.random() * 10);
			System.out.println(RandomNumbers);
			int InputNum= input.nextInt();

		  if(Points == 10){
			Points=0;
			Scanner inNames = new Scanner(System.in);
		    System.out.println("***********************");
			  System.out.println(Player1Name + " " + "is Wins"+" & "+Player1Name+" "+"points is"+" "+"("+Points+")"+" & "+Player2Name+" "+"points is"+" "+"("+P2Point+")");
		    System.out.println("***********************");
		    System.out.println();
		    System.out.println("Do you want to play Again y/n");
		    File D = new File(Address);
		    D.delete();
		    File D2 = new File(Address2);
		    D2.delete();
			char Res = input.next().charAt(0);
		    if(Res=='y' || Res=='Y'){
			
		    System.out.println("P1 enter your name");
            String P1Name = new String(inNames.nextLine());
			
		    System.out.println("P2 enter your name");
            String P2Name = new String(inNames.nextLine());
			
		    Player1 R = new Player1();
		    R.startP1(P1Name,P2Name,Points,P2Point);
			
			}
		  }
			
			if (InputNum == RandomNumbers)
			{
				Points++;
				System.out.println("=============================");
				System.out.println("You Enter Right Number");
				System.out.println("Your points is +"+Points+" or 1 more try");
				System.out.println("============================="); 
				
				File AddPoints = new File(Address);

				try
				{
					AddPoints.createNewFile();
				}
				catch (IOException e)
				{
					System.out.println("Error!" + e);
				}
				try
				{
					FileWriter AddPointsWrite = new FileWriter(Address);
					AddPointsWrite.write(Player1Name + "=" + "Points" + "(" + Points + ")");
					AddPointsWrite.close();
				}
				catch (IOException e)
				{
					System.out.println("Error!" + e);
				}
			}
			else if (InputNum == 109885)
			{
				File file = new File(Address);
				Scanner Read = new Scanner(file);
				
				System.out.println("********************");
				Read.useDelimiter("\\z");
				System.out.println(Read.next());
				System.out.println("********************");   
			}
			else if (InputNum == 3485)
			{
				File Delete = new File(Address);
				Delete.deleteOnExit();
				File Delete2 = new File(Address2);
				Delete2.deleteOnExit();
				System.exit(1);
			}
			else{
				Player2 P1 = new Player2();
				P1.startP2(Player1Name,Player2Name,Points,P2Point);
				}

		}while(Points!=11);
	}

}
